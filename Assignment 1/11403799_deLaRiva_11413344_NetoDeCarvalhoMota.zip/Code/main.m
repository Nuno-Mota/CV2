clc

% 3.1.a
%MergingICP(1, 1, 99, '3.1.a', 'Uniform', 1000)


% 3.1.b
% MergingICP(1, 2, 50, '3.1.b', 'Uniform', 10000)

MergingICP(1, 4, 99, '3.1.b', 'Random', 10000)

% MergingICP(1, 10, 50, '3.1.b', 'Uniform', 10000)


% 3.2
% MergingICP(1, 1, 99, '3.2', 'Uniform', 4000)